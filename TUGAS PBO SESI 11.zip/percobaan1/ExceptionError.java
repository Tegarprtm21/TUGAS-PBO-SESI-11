package com.percobaan1;

public class ExceptionError {
    public static void main(String[] args) {
        int a[] = new int[5];
        a[5]=100;
    }
}
