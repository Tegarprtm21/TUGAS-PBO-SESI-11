package com.percobaan3;

public class ExceptionError {
    public static void main(String[] args) {
        int bil=10;
        System.out.println(bil/0);
    }
}
